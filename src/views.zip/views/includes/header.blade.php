<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>My Cart | {{ env('APP_NAME') }} </title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="{{ asset('checkout/css/style.css') }}">

    @if(request()->segment(1) === 'order' && request()->segment(3) === 'checkout' && request()->segment(4) === 'pay')
        <link rel="stylesheet" href="{{ asset('checkout/stripe/css/normalize.css') }}" />
        <link rel="stylesheet" href="{{ asset('checkout/stripe/css/global.css') }}" />
        <script src="https://js.stripe.com/v3/"></script>
        <script src="{{ asset('checkout/stripe/js/script.js') }}" defer></script>
    @endif

</head>
