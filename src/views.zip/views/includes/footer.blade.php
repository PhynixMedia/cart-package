<!-- JS here -->
    <script src="{{ asset('checkout/js/vendor/modernizr-3.5.0.min.js') }}"></script>
    <script src="{{ asset('checkout/js/vendor/jquery-1.12.4.min.js') }}"></script>
    <script src="{{ asset('checkout/js/popper.min.js') }}"></script>
    <script src="{{ asset('checkout/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('checkout/js/owl.carousel.min.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.nav.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.easing.min.js') }}"></script>
    <script src="{{ asset('checkout/js/isotope.pkgd.min.js') }}"></script>
    <script src="{{ asset('checkout/js/waypoints.min.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.counterup.min.js') }}"></script>
    <script src="{{ asset('checkout/js/imagesloaded.pkgd.min.js') }}"></script>
    <script src="{{ asset('checkout/js/scrollIt.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.scrollUp.min.js') }}"></script>
    <script src="{{ asset('checkout/js/wow.min.js') }}"></script>
    <script src="{{ asset('checkout/js/nice-select.min.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.slicknav.min.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.magnific-popup.min.js') }}"></script>
    <script src="{{ asset('checkout/js/slick.min.js') }}"></script>
    <script src="{{ asset('checkout/js/jquery.animatedheadline.min.js') }}"></script>
    <script src="{{ asset('checkout/js/classy-nav.js') }}"></script>

    <!-- Custom js-->
    <script src="{{ asset('checkout/js/main.js') }}"></script>
    <script src="{{ asset('checkout/js/shopping-cart.js') }}"></script>
