                        <div class="row no-gutters">
                            
                            <div class="col-md-3 col-lg-3 no-gutters">
                                <div class="price-table-heading">
                                    
                                @include("cart::includes.logo")

                                </div>
                            </div>
                            <div class="col-md-3 col-lg-3 no-gutters nav-table-heading">
                                <div class="price-table-heading">
                                    <div class="header-wrap">
                                        <h6>Checkout</h6>
                                        <p>Order information</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-lg-3 no-gutters nav-table-heading">
                                <div class="price-table-heading">
                                    <div class="header-wrap">
                                        <h6>Payment</h6>
                                        <p>Secure checkout</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-lg-3 no-gutters nav-table-heading">
                                <div class="price-table-heading">
                                    <div class="header-wrap">
                                        <h6>Confirm</h6>
                                        <p>Order Complete</p>
                                    </div>
                                </div>
                            </div>
                        </div>