<div class="price-table-body">
                            <div class="row justify-content-center">

                                <div class="col-md-10 col-lg-7">

                                    <h3 class="text-center">Make Payment</h3>

                                    @include("cart::payment.stripe.pay")


                                    <h6 class="text-center">Be Rewarded Each time you checkout with us!</h6>
                                    <p class="text-center">
                                        We reward our customers for placing their orders with us. We do this in addition to our 
                                        quality product so all our customers enjoy the value for their money.
                                    </p>
                                    
                                </div>

                                
                            </div>

                        </div>