
                                                    <div class="checkout-login">
                                        
                                                        <div class="title-wrap">
                                                            <h6 class="cart-bottom-title section-bg-white">REGISTER AND SAVE TIME!</h6>
                                                        </div>
                                                        <!-- <h6>REGISTER AND SAVE TIME!</h6> -->
                                                        <p class="register-us-2">
                                                            <p>Register with us for future convenience...</p>
                
                                                        </p>
                                                        <div class="checkout-login-btn" style="margin-top:20px">
                                                            <a class="btn btn-danger" href="{{-- route('user.signup') --}}"> <i class="fa fa-arrow-right"></i> Create Account</a>
                                                        </div>

                                                        <hr />

                                                        <div class="title-wrap">
                                                            <h6 class="cart-bottom-title section-bg-white">HAVE AN ACCOUNT?</h6>
                                                        </div>
                                                        <p>login to view your reward points if you already have an account? </p>
                                                        <!-- <span>Please log in below:</span> -->
                                                        
                                                        <div class="checkout-login-btn">
                                                            <a class="btn btn-danger" href="{{-- route('user.login') --}}"> <i class="fa fa-arrow-right"></i> Login</a>
                                                        </div>

                                                    </div>
                                                